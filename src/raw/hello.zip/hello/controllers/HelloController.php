<?php
namespace hello\controllers;

use wulaphp\mvc\controller\Controller;

class HelloController extends Controller {
	public function index() {
		// 注意此外，我们直接返回了'hello world'
		return 'hello world';
	}

	public function world() {
		$data['message'] = 'hello world';

		// 当方法名与模板名相同时，可以省略模板名.
		return view($data);
	}

	public function say($name = '') {
		$data['message'] = $name . '，你好!';

		return view('world', $data);
	}
}