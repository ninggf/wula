<?php

namespace hello\controllers;

use wulaphp\mvc\controller\Controller;

class NiuBiController extends Controller {
	public function say() {

		return view(['niubi' => 'wula is very niubi!']);
	}
}