<?php
namespace hello;

use wulaphp\app\App;
use wulaphp\app\Module;

class HelloModule extends Module {
	public function getName() {
		return 'helloworld';
	}

	public function getDescription() {
		return '输出helloworld的演示模块';
	}

	public function getHomePageURL() {
		return '';
	}

}

App::register(new HelloModule());
